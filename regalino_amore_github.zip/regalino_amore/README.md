# Regalino per amore 💗
Sito romantico responsive, pensato per smartphone.

## Personalizzalo
- In `index.html`, cerca `CODICE_SEGRETO="143"` e sostituisci 143 con il vostro codice.
- Modifica il messaggio dentro `id="secret"` con parole tue.
- La foto si sceglie dalla galleria quando si apre il sito (non viene caricata su GitHub).

## Pubblicarlo con GitHub Pages
1. Crea un repository GitHub (es. `regalino`).
2. Carica `index.html` nella root del repository.
3. Vai in **Settings → Pages**.
4. In **Build and deployment**, seleziona **Deploy from a branch**.
5. Scegli `main` e `/ (root)`, poi **Save**.
6. Dopo qualche minuto il sito sarà su `https://TUONOME.github.io/regalino/`.

Per vedere il sito prima di pubblicarlo, apri `index.html` nel browser oppure usa l'anteprima di un editor.
